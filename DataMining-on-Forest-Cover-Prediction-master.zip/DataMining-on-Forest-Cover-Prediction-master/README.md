# DataMining-on-Forest-Cover-Prediction
The goal is to predict an integer classification for the forest cover type from strictly cartographic variables 
using data mining and machine learning techniques.

The following approaches were used for classification:
1. K-Nearest Neighbor
2. Gaussian Naive Bayes
3. Support Vector Machines
4. Gradient Tree Boosting
5. Decision Trees
6. Random Forests
7. Extra Tree Classifier
